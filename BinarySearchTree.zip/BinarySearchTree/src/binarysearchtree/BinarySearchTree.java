package binarysearchtree;

import java.util.Scanner;

public class BinarySearchTree {

    private Node root;

    class Node {

        private int data;
        private Node left;
        private Node right;

        public Node(int data) {
            this.data = data;
            this.left = this.right;
        }

    }

    private void deleteValue(int data) {
        root = deleteRec(root, data);
    }

    private Node search(int key) {
        return searchRec(root, key);
    }

    private void preOrder() {
        preOrderRec(root);
    }

    private void insertValue(int value) {
        root = insertRec(root, value);
    }

    private Node insertRec(Node root, int value) {
        if (root == null) {
            root = new Node(value);
            return root;
        }

        if (value < root.data) {
            root.left = insertRec(root.left, value);
        } else {
            root.right = insertRec(root.right, value);
        }
        return root;
    }

    private void preOrderRec(Node root) {
        if (root == null) {
            return;
        }

        System.out.println(root.data + " ");
        preOrderRec(root.left);
        preOrderRec(root.right);
    }

    private Node searchRec(Node root, int key) {
        if (root == null || root.data == key) {
            return root;
        }

        if (key < root.data) {
            return searchRec(root.left, key);
        } else {
            return searchRec(root.right, key);
        }
    }

    private Node deleteRec(Node root, int data) {
        if (root == null) {
            return null;
        }

        if (data < root.data) {
            root.left = deleteRec(root.left, data);
        } else if (data > root.data) {
            root.right = deleteRec(root.right, data);
        } else {
            if (root.left == null) {
                return root.right;
            } else if (root.right == null) {
                return root.left;
            }
            root.data = minValue(root.right);

            root.right = deleteRec(root.right, root.data);
        }
        return root;
    }

    private int minValue(Node root) {
        int minV = root.data;
        while (root.left != null) {
            minV = root.left.data;
            root = root.left;
        }
        return minV;
    }

    public static void main(String[] args) {
        BinarySearchTree bst = new BinarySearchTree();
        Scanner sc = new Scanner(System.in);
        int option;

        do {
            System.out.println("Menu");
            System.out.println("================");
            System.out.println("1.INSERTION");
            System.out.println("2.PRE-ORDER");
            System.out.println("3.SEARCH");
            System.out.println("4.DELETE");
            System.out.println("5.EXIT");
            System.out.println("================");
            System.out.println("Enter Option:");
            option = sc.nextInt();

            switch (option) {
                case 1:
                    System.out.println("Enter Value:");
                    int value = sc.nextInt();

                    bst.insertValue(value);
                    break;
                case 2:
                    bst.preOrder();
                    break;
                case 3:
                    System.out.println("Enter Key to search:");
                    int key = sc.nextInt();

                    if (null != bst.search(key)) {
                        System.out.println("True");
                    } else {
                        System.out.println("False");
                    }
                    break;
                case 4:
                    System.out.println("Enter key to delete:");
                    int data = sc.nextInt();

                    bst.deleteValue(data);
                    break;

                case 5:
                    System.out.println("Thank you!!!!!");
                    break;
                default:
                    System.out.println("Invalid Number!!!!!!!");

            }

        } while (option != 5);

    }

}
